import "./App.css";
import Appbar from "./components/Appbar/Appbar";
import Sidebar from "./components/Sidebar/Sidebar";
import Tabs from "./components/Tabs/Tabs";

function App() {
  return (
    <div className="App">
      <Sidebar />
      <div className="main">
        <Appbar />
        <Tabs />
      </div>
    </div>
  );
}

export default App;
